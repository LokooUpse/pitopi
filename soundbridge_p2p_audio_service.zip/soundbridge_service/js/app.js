// SoundBridge P2P - Real-time PC System Audio to Phone Streaming Service
// Works on 100% free static web hosting (GitHub Pages, Netlify, Vercel, Cloudflare Pages)
// via WebRTC + PeerJS Cloud STUN/Signaling + Manual SDP Fallback.

(function () {
  'use strict';

  // --- Application State ---
  const state = {
    role: 'host', // 'host' | 'client' | 'guide'
    sourceType: 'system', // 'system' | 'device' | 'synth' | 'file'
    signalingMode: 'peerjs', // 'peerjs' | 'custom' | 'manual'
    roomCode: '',
    peer: null,
    hostStream: null,
    processedStream: null,
    audioCtx: null,
    analyser: null,
    gainNode: null,
    eqNodes: { bass: null, mid: null, treble: null },
    synthOsc: null,
    synthGain: null,
    synthTimer: null,
    fileAudioEl: null,
    isStreaming: false,
    localMonitor: false,
    bitrate: 256,
    stereo: true,
    connectedClients: new Map(), // peerId -> { call, conn, connectedAt, label }
    // Client state
    clientPeer: null,
    clientConn: null,
    clientCall: null,
    clientConnected: false,
    clientPlaying: false,
    remoteStream: null,
    wakeLock: null,
    vizMode: 'bars', // 'bars' | 'wave'
    animFrameId: null,
    statsIntervalId: null,
    customServer: {
      host: '0.peerjs.com',
      port: 443,
      path: '/',
      secure: true
    },
    manualPeerConn: null
  };

  // --- Utility Helpers ---
  function generateRoomCode() {
    const chars = '23456789ABCDEFGHJKLMNPQRSTUVWXYZ';
    let code = '';
    for (let i = 0; i < 6; i++) {
      code += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return code;
  }

  function showToast(message, type) {
    const container = document.getElementById('toast-container');
    if (!container) return;
    const toast = document.createElement('div');
    const colorClass =
      type === 'error'
        ? 'border-rose-500/60 bg-rose-950/90 text-rose-100'
        : type === 'warning'
        ? 'border-amber-500/60 bg-amber-950/90 text-amber-100'
        : 'border-sky-500/60 bg-slate-900/95 text-sky-100';
    toast.className =
      'px-4 py-3 rounded-xl border shadow-xl text-sm font-medium flex items-center gap-2.5 transition-all duration-300 ' +
      colorClass;
    toast.innerHTML =
      '<span class="w-2 h-2 rounded-full ' +
      (type === 'error' ? 'bg-rose-400' : type === 'warning' ? 'bg-amber-400' : 'bg-sky-400') +
      '"></span><span>' +
      escapeHtml(message) +
      '</span>';
    container.appendChild(toast);
    setTimeout(function () {
      toast.style.opacity = '0';
      toast.style.transform = 'translateY(8px)';
      setTimeout(function () {
        if (toast.parentNode) toast.parentNode.removeChild(toast);
      }, 300);
    }, 3600);
  }

  function escapeHtml(str) {
    return String(str)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  function copyText(text, label) {
    try {
      if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(text).then(function () {
          showToast(label || 'Скопировано в буфер обмена', 'info');
        }).catch(function () {
          fallbackCopy(text, label);
        });
      } else {
        fallbackCopy(text, label);
      }
    } catch (e) {
      fallbackCopy(text, label);
    }
  }

  function fallbackCopy(text, label) {
    const ta = document.createElement('textarea');
    ta.value = text;
    ta.style.position = 'fixed';
    ta.style.opacity = '0';
    document.body.appendChild(ta);
    ta.select();
    try {
      document.execCommand('copy');
      showToast(label || 'Скопировано в буфер обмена', 'info');
    } catch (err) {
      showToast('Не удалось скопировать автоматически', 'warning');
    }
    document.body.removeChild(ta);
  }

  // --- SDP Manipulation for High-Bitrate Stereo Opus ---
  function enhanceOpusSdp(sdp, bitrateKbps, enableStereo) {
    if (!sdp) return sdp;
    const lines = sdp.split('\r\n');
    let opusPayload = null;
    for (let i = 0; i < lines.length; i++) {
      const m = lines[i].match(/^a=rtpmap:(\d+) opus\/48000\/2/i);
      if (m) {
        opusPayload = m[1];
        break;
      }
    }
    if (!opusPayload) return sdp;

    const bps = (bitrateKbps || 256) * 1000;
    const stereoFlag = enableStereo ? 1 : 0;
    const extraParams =
      'stereo=' +
      stereoFlag +
      ';sprop-stereo=' +
      stereoFlag +
      ';maxaveragebitrate=' +
      bps +
      ';cbr=1;useinbandfec=1;usedtx=0;maxptime=20';

    let fmtpFound = false;
    for (let i = 0; i < lines.length; i++) {
      if (lines[i].indexOf('a=fmtp:' + opusPayload + ' ') === 0) {
        lines[i] = lines[i] + ';' + extraParams;
        fmtpFound = true;
        break;
      }
    }
    if (!fmtpFound) {
      const newLines = [];
      for (let i = 0; i < lines.length; i++) {
        newLines.push(lines[i]);
        if (lines[i].indexOf('a=rtpmap:' + opusPayload + ' ') === 0) {
          newLines.push('a=fmtp:' + opusPayload + ' minptime=10;' + extraParams);
        }
      }
      return newLines.join('\r\n');
    }
    return lines.join('\r\n');
  }

  // --- QR Code Generator (Visual Matrix + qrcodejs if available) ---
  function renderQrCode(url) {
    const container = document.getElementById('qr-container');
    if (!container) return;
    container.innerHTML = '';

    if (typeof window.QRCode === 'function') {
      try {
        new window.QRCode(container, {
          text: url,
          width: 156,
          height: 156,
          colorDark: '#0f172a',
          colorLight: '#ffffff',
          correctLevel: window.QRCode.CorrectLevel.M
        });
        return;
      } catch (e) {
        // Fallback to canvas badge below
      }
    }

    // Fallback deterministic visual QR matrix canvas if CDN is offline
    const canvas = document.createElement('canvas');
    canvas.width = 156;
    canvas.height = 156;
    const ctx = canvas.getContext('2d');
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, 156, 156);
    ctx.fillStyle = '#0f172a';
    const size = 21;
    const cell = Math.floor(140 / size);
    const offset = 8;

    function drawFinder(r0, c0) {
      for (let r = 0; r < 7; r++) {
        for (let c = 0; c < 7; c++) {
          if (
            r === 0 ||
            r === 6 ||
            c === 0 ||
            c === 6 ||
            (r >= 2 && r <= 4 && c >= 2 && c <= 4)
          ) {
            ctx.fillRect(offset + (c0 + c) * cell, offset + (r0 + r) * cell, cell, cell);
          }
        }
      }
    }
    drawFinder(0, 0);
    drawFinder(0, size - 7);
    drawFinder(size - 7, 0);

    let hash = 2166136261;
    for (let i = 0; i < url.length; i++) {
      hash ^= url.charCodeAt(i);
      hash = Math.imul(hash, 16777619);
    }
    for (let r = 0; r < size; r++) {
      for (let c = 0; c < size; c++) {
        const inFinder =
          (r < 8 && c < 8) || (r < 8 && c >= size - 8) || (r >= size - 8 && c < 8);
        if (inFinder) continue;
        hash ^= (r * 31 + c * 17) & 0xff;
        hash = Math.imul(hash, 16777619);
        if ((Math.abs(hash) % 10) < 5) {
          ctx.fillRect(offset + c * cell, offset + r * cell, cell, cell);
        }
      }
    }
    container.appendChild(canvas);
  }

  function getShareUrl() {
    let base = window.location.href.split('?')[0].split('#')[0];
    return base + '?role=client&room=' + encodeURIComponent(state.roomCode);
  }

  function updateRoomDisplay() {
    const codeEl = document.getElementById('host-room-code');
    const urlEl = document.getElementById('host-share-url');
    if (codeEl) codeEl.textContent = state.roomCode;
    const shareUrl = getShareUrl();
    if (urlEl) urlEl.value = shareUrl;
    renderQrCode(shareUrl);
  }

  // --- Audio Graph & EQ Setup ---
  function ensureAudioContext() {
    if (!state.audioCtx) {
      const AudioCtx = window.AudioContext || window.webkitAudioContext;
      state.audioCtx = new AudioCtx({ latencyHint: 'interactive', sampleRate: 48000 });
    }
    if (state.audioCtx.state === 'suspended') {
      state.audioCtx.resume();
    }
    return state.audioCtx;
  }

  function buildAudioPipeline(rawStream, isClient) {
    const ctx = ensureAudioContext();
    const source = ctx.createMediaStreamSource(rawStream);

    const bass = ctx.createBiquadFilter();
    bass.type = 'lowshelf';
    bass.frequency.value = 100;
    bass.gain.value = parseFloat(document.getElementById(isClient ? 'client-eq-bass' : 'host-eq-bass')?.value || '0');

    const mid = ctx.createBiquadFilter();
    mid.type = 'peaking';
    mid.frequency.value = 1000;
    mid.Q.value = 1.0;
    mid.gain.value = parseFloat(document.getElementById(isClient ? 'client-eq-mid' : 'host-eq-mid')?.value || '0');

    const treble = ctx.createBiquadFilter();
    treble.type = 'highshelf';
    treble.frequency.value = 8000;
    treble.gain.value = parseFloat(document.getElementById(isClient ? 'client-eq-treble' : 'host-eq-treble')?.value || '0');

    const gainNode = ctx.createGain();
    const gainSlider = document.getElementById(isClient ? 'client-volume' : 'host-gain');
    gainNode.gain.value = gainSlider ? parseFloat(gainSlider.value) / 100 : 1.0;

    const analyser = ctx.createAnalyser();
    analyser.fftSize = 512;
    analyser.smoothingTimeConstant = 0.82;

    source.connect(bass);
    bass.connect(mid);
    mid.connect(treble);
    treble.connect(gainNode);
    gainNode.connect(analyser);

    state.eqNodes = { bass: bass, mid: mid, treble: treble };
    state.gainNode = gainNode;
    state.analyser = analyser;

    if (isClient) {
      gainNode.connect(ctx.destination);
      startVisualizer();
      return null;
    } else {
      const dest = ctx.createMediaStreamDestination();
      gainNode.connect(dest);
      if (state.localMonitor) {
        gainNode.connect(ctx.destination);
      }
      startVisualizer();
      return dest.stream;
    }
  }

  // --- Visualizer Loop ---
  function startVisualizer() {
    if (state.animFrameId) {
      cancelAnimationFrame(state.animFrameId);
    }
    const canvas = document.getElementById('visualizer-canvas');
    if (!canvas) return;
    const ctx = canvas.getContext('2d');

    function draw() {
      state.animFrameId = requestAnimationFrame(draw);
      const width = canvas.width;
      const height = canvas.height;
      ctx.clearRect(0, 0, width, height);

      // Subtle background grid
      ctx.strokeStyle = 'rgba(51, 65, 85, 0.3)';
      ctx.lineWidth = 1;
      for (let y = height / 4; y < height; y += height / 4) {
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(width, y);
        ctx.stroke();
      }

      if (!state.analyser) {
        ctx.fillStyle = '#64748b';
        ctx.font = '12px Inter, sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText('Ожидание аудиопотока...', width / 2, height / 2 + 4);
        updateDbMeter(-60);
        return;
      }

      const bufferLen = state.analyser.frequencyBinCount;
      const dataArray = new Uint8Array(bufferLen);

      if (state.vizMode === 'bars') {
        state.analyser.getByteFrequencyData(dataArray);
        const barCount = 48;
        const step = Math.floor(bufferLen / barCount);
        const barWidth = (width / barCount) * 0.72;
        const gap = (width / barCount) * 0.28;

        let sumSquares = 0;
        for (let i = 0; i < barCount; i++) {
          const val = dataArray[i * step];
          sumSquares += val * val;
          const pct = val / 255;
          const barHeight = Math.max(4, pct * (height - 16));
          const x = i * (barWidth + gap) + gap / 2;
          const y = height - barHeight;

          const grad = ctx.createLinearGradient(0, height, 0, 0);
          grad.addColorStop(0, '#0284c7');
          grad.addColorStop(0.6, '#38bdf8');
          grad.addColorStop(1, '#a855f7');
          ctx.fillStyle = grad;
          ctx.beginPath();
          ctx.roundRect ? ctx.roundRect(x, y, barWidth, barHeight, 3) : ctx.rect(x, y, barWidth, barHeight);
          ctx.fill();
        }
        const rms = Math.sqrt(sumSquares / barCount) / 255;
        const db = rms > 0.001 ? Math.max(-60, Math.min(0, 20 * Math.log10(rms))) : -60;
        updateDbMeter(db);
      } else {
        state.analyser.getByteTimeDomainData(dataArray);
        ctx.lineWidth = 2.5;
        ctx.strokeStyle = '#38bdf8';
        ctx.beginPath();
        const sliceWidth = width / bufferLen;
        let x = 0;
        let sumSquares = 0;
        for (let i = 0; i < bufferLen; i++) {
          const v = dataArray[i] / 128.0;
          const centered = v - 1.0;
          sumSquares += centered * centered;
          const y = (v * height) / 2;
          if (i === 0) ctx.moveTo(x, y);
          else ctx.lineTo(x, y);
          x += sliceWidth;
        }
        ctx.lineTo(width, height / 2);
        ctx.stroke();
        const rms = Math.sqrt(sumSquares / bufferLen);
        const db = rms > 0.001 ? Math.max(-60, Math.min(0, 20 * Math.log10(rms))) : -60;
        updateDbMeter(db);
      }
    }
    draw();
  }

  function updateDbMeter(db) {
    const dbText = document.getElementById('db-meter-text');
    const dbBar = document.getElementById('db-meter-bar');
    if (dbText) {
      dbText.textContent = db <= -59 ? '-∞ dB' : db.toFixed(1) + ' dB';
    }
    if (dbBar) {
      const pct = Math.max(0, Math.min(100, ((db + 60) / 60) * 100));
      dbBar.style.width = pct + '%';
    }
  }

  // --- Audio Input Enumeration ---
  async function refreshAudioDevices() {
    const select = document.getElementById('audio-device-select');
    if (!select || !navigator.mediaDevices || !navigator.mediaDevices.enumerateDevices) return;
    try {
      const devices = await navigator.mediaDevices.enumerateDevices();
      const audioInputs = devices.filter(function (d) {
        return d.kind === 'audioinput';
      });
      select.innerHTML = '';
      if (audioInputs.length === 0) {
        const opt = document.createElement('option');
        opt.value = '';
        opt.textContent = 'Аудиоустройства по умолчанию';
        select.appendChild(opt);
      } else {
        audioInputs.forEach(function (dev, idx) {
          const opt = document.createElement('option');
          opt.value = dev.deviceId;
          opt.textContent = dev.label || 'Аудиовход #' + (idx + 1) + ' (Стерео микшер / Кабель)';
          select.appendChild(opt);
        });
      }
    } catch (e) {
      // Ignore permission error prior to user gesture
    }
  }

  // --- Built-in Demo Synth Stream (for instant testing without screen share) ---
  function createDemoSynthStream() {
    const ctx = ensureAudioContext();
    const dest = ctx.createMediaStreamDestination();
    const master = ctx.createGain();
    master.gain.value = 0.25;
    master.connect(dest);

    const notes = [261.63, 329.63, 392.00, 523.25, 392.00, 329.63];
    let step = 0;

    const osc = ctx.createOscillator();
    const noteGain = ctx.createGain();
    osc.type = 'triangle';
    osc.frequency.value = notes[0];
    noteGain.gain.value = 0.5;

    osc.connect(noteGain);
    noteGain.connect(master);
    osc.start();

    state.synthOsc = osc;
    state.synthGain = master;
    state.synthTimer = setInterval(function () {
      step = (step + 1) % notes.length;
      if (state.audioCtx && state.synthOsc) {
        state.synthOsc.frequency.setTargetAtTime(notes[step], state.audioCtx.currentTime, 0.03);
      }
    }, 420);

    return dest.stream;
  }

  function stopDemoSynth() {
    if (state.synthTimer) {
      clearInterval(state.synthTimer);
      state.synthTimer = null;
    }
    if (state.synthOsc) {
      try {
        state.synthOsc.stop();
        state.synthOsc.disconnect();
      } catch (e) {}
      state.synthOsc = null;
    }
  }

  // --- Host: Capture Audio Stream ---
  async function acquireHostAudioStream() {
    stopExistingStreams();

    if (state.sourceType === 'system') {
      if (!navigator.mediaDevices || !navigator.mediaDevices.getDisplayMedia) {
        throw new Error(
          'Ваш браузер не поддерживает захват системного звука (getDisplayMedia). Откройте сервис на ПК в Chrome, Edge, Brave или Яндекс.Браузере, либо выберите режим «Демо-синтезатор» или «Аудиоустройство».'
        );
      }
      // Important: Chromium requires video: true to show the screen/system audio picker
      const displayStream = await navigator.mediaDevices.getDisplayMedia({
        video: {
          width: { ideal: 320 },
          height: { ideal: 180 },
          frameRate: { ideal: 5 }
        },
        audio: {
          echoCancellation: false,
          noiseSuppression: false,
          autoGainControl: false,
          channelCount: 2,
          sampleRate: 48000
        },
        systemAudio: 'include'
      });

      const audioTracks = displayStream.getAudioTracks();
      // Immediately stop video tracks so we only stream pure audio and save 100% video bandwidth
      displayStream.getVideoTracks().forEach(function (vt) {
        vt.stop();
        displayStream.removeTrack(vt);
      });

      if (audioTracks.length === 0) {
        throw new Error(
          'Системный звук не был выбран! В окне выбора экрана обязательно поставьте галочку «Поделиться системным звуком» (Also share system audio).'
        );
      }

      const audioTrack = audioTracks[0];
      if ('contentHint' in audioTrack) {
        audioTrack.contentHint = 'music';
      }
      audioTrack.addEventListener('ended', function () {
        showToast('Захват системного звука остановлен', 'warning');
        stopHostBroadcast();
      });

      return new MediaStream([audioTrack]);
    } else if (state.sourceType === 'device') {
      const deviceId = document.getElementById('audio-device-select')?.value;
      const constraints = {
        audio: {
          deviceId: deviceId ? { exact: deviceId } : undefined,
          echoCancellation: false,
          noiseSuppression: false,
          autoGainControl: false,
          channelCount: 2,
          sampleRate: 48000
        },
        video: false
      };
      const userStream = await navigator.mediaDevices.getUserMedia(constraints);
      await refreshAudioDevices();
      return userStream;
    } else if (state.sourceType === 'file') {
      const fileInput = document.getElementById('host-audio-file');
      if (!fileInput || !fileInput.files || fileInput.files.length === 0) {
        throw new Error('Пожалуйста, выберите аудиофайл (.mp3, .wav, .ogg) для трансляции.');
      }
      const fileUrl = URL.createObjectURL(fileInput.files[0]);
      const audioEl = new Audio(fileUrl);
      audioEl.loop = true;
      await audioEl.play();
      state.fileAudioEl = audioEl;
      const ctx = ensureAudioContext();
      const src = ctx.createMediaElementSource(audioEl);
      const dest = ctx.createMediaStreamDestination();
      src.connect(dest);
      return dest.stream;
    } else {
      // 'synth' demo generator
      return createDemoSynthStream();
    }
  }

  function stopExistingStreams() {
    stopDemoSynth();
    if (state.fileAudioEl) {
      state.fileAudioEl.pause();
      state.fileAudioEl.src = '';
      state.fileAudioEl = null;
    }
    if (state.hostStream) {
      state.hostStream.getTracks().forEach(function (t) {
        t.stop();
      });
      state.hostStream = null;
    }
  }

  // --- Host: Start / Stop Broadcast ---
  async function startHostBroadcast() {
    try {
      const rawStream = await acquireHostAudioStream();
      state.hostStream = rawStream;
      state.processedStream = buildAudioPipeline(rawStream, false);
      state.isStreaming = true;

      updateHostUiStatus(true);
      initHostPeer();
      showToast('Трансляция звука с ПК запущена! Подключитесь с телефона по коду ' + state.roomCode, 'info');
    } catch (err) {
      showToast(err.message || 'Ошибка при захвате звука', 'error');
      updateHostUiStatus(false);
    }
  }

  function stopHostBroadcast() {
    state.isStreaming = false;
    stopExistingStreams();
    state.connectedClients.forEach(function (client) {
      try {
        if (client.call) client.call.close();
        if (client.conn) client.conn.close();
      } catch (e) {}
    });
    state.connectedClients.clear();
    renderConnectedClients();

    if (state.peer) {
      try {
        state.peer.destroy();
      } catch (e) {}
      state.peer = null;
    }
    updateHostUiStatus(false);
    showToast('Трансляция остановлена', 'info');
  }

  function updateHostUiStatus(active) {
    const startBtn = document.getElementById('btn-host-start');
    const stopBtn = document.getElementById('btn-host-stop');
    const badge = document.getElementById('host-status-badge');
    if (startBtn) startBtn.classList.toggle('hidden', active);
    if (stopBtn) stopBtn.classList.toggle('hidden', !active);
    if (badge) {
      badge.className = active
        ? 'inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-semibold bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
        : 'inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-semibold bg-slate-800 text-slate-400 border border-slate-700';
      badge.innerHTML = active
        ? '<span class="w-2 h-2 rounded-full bg-emerald-400 pulse-dot"></span>В эфире (' + state.bitrate + ' kbps Стерео)'
        : '<span class="w-2 h-2 rounded-full bg-slate-500"></span>Ожидание запуска';
    }
  }

  // --- PeerJS Signaling Setup for Host ---
  function getPeerConfig() {
    const iceServers = [
      { urls: 'stun:stun.l.google.com:19302' },
      { urls: 'stun:stun1.l.google.com:19302' },
      { urls: 'stun:stun2.l.google.com:19302' },
      { urls: 'stun:stun.cloudflare.com:3478' }
    ];
    const base = {
      debug: 1,
      config: {
        iceServers: iceServers,
        sdpSemantics: 'unified-plan'
      }
    };
    if (state.signalingMode === 'custom') {
      base.host = document.getElementById('custom-peer-host')?.value || 'localhost';
      base.port = parseInt(document.getElementById('custom-peer-port')?.value || '9000', 10);
      base.path = document.getElementById('custom-peer-path')?.value || '/myapp';
      base.secure = document.getElementById('custom-peer-secure')?.checked ?? false;
    }
    return base;
  }

  function initHostPeer() {
    if (state.signalingMode === 'manual') {
      showToast('Ручной SDP-режим активен: создайте SDP-предложение во вкладке ниже', 'info');
      return;
    }
    if (typeof window.Peer !== 'function') {
      showToast('Библиотека PeerJS не загружена — используйте ручной WebRTC SDP режим', 'warning');
      return;
    }
    if (state.peer) {
      try {
        state.peer.destroy();
      } catch (e) {}
    }

    const peerId = 'soundbridge-host-' + state.roomCode;
    const peer = new window.Peer(peerId, getPeerConfig());
    state.peer = peer;

    peer.on('open', function () {
      const sigStatus = document.getElementById('signaling-status-text');
      if (sigStatus) sigStatus.textContent = 'Сигналинг подключен (ID: ' + state.roomCode + ')';
    });

    peer.on('connection', function (conn) {
      conn.on('open', function () {
        conn.send({
          type: 'host-meta',
          bitrate: state.bitrate,
          stereo: state.stereo,
          sourceType: state.sourceType
        });

        // Call the connecting phone with the processed high-bitrate audio stream
        if (state.processedStream) {
          const call = peer.call(conn.peer, state.processedStream, {
            sdpTransform: function (sdp) {
              return enhanceOpusSdp(sdp, state.bitrate, state.stereo);
            }
          });
          registerClient(conn.peer, call, conn);
        }
      });

      conn.on('data', function (data) {
        if (data && data.type === 'request-stream' && state.processedStream) {
          const call = peer.call(conn.peer, state.processedStream, {
            sdpTransform: function (sdp) {
              return enhanceOpusSdp(sdp, state.bitrate, state.stereo);
            }
          });
          registerClient(conn.peer, call, conn, data.deviceLabel);
        } else if (data && data.type === 'ping') {
          conn.send({ type: 'pong', ts: data.ts });
        }
      });

      conn.on('close', function () {
        removeClient(conn.peer);
      });
    });

    peer.on('call', function (incomingCall) {
      // If client initiates a media call with a dummy audio track, answer with host stream
      if (state.processedStream) {
        incomingCall.answer(state.processedStream, {
          sdpTransform: function (sdp) {
            return enhanceOpusSdp(sdp, state.bitrate, state.stereo);
          }
        });
        registerClient(incomingCall.peer, incomingCall, null);
      }
    });

    peer.on('error', function (err) {
      if (err && err.type === 'unavailable-id') {
        state.roomCode = generateRoomCode();
        updateRoomDisplay();
        initHostPeer();
      } else {
        showToast('Статус сети PeerJS: ' + (err.type || err.message), 'warning');
      }
    });
  }

  function registerClient(peerId, call, conn, label) {
    const existing = state.connectedClients.get(peerId) || {};
    state.connectedClients.set(peerId, {
      call: call || existing.call,
      conn: conn || existing.conn,
      connectedAt: existing.connectedAt || new Date().toLocaleTimeString(),
      label: label || existing.label || 'Смартфон (' + peerId.slice(-5) + ')'
    });
    renderConnectedClients();
    showToast('Телефон подключился к аудиопотоку!', 'info');
  }

  function removeClient(peerId) {
    const client = state.connectedClients.get(peerId);
    if (client) {
      try {
        if (client.call) client.call.close();
        if (client.conn) client.conn.close();
      } catch (e) {}
      state.connectedClients.delete(peerId);
      renderConnectedClients();
    }
  }

  function renderConnectedClients() {
    const listEl = document.getElementById('connected-clients-list');
    const countEl = document.getElementById('connected-clients-count');
    if (countEl) countEl.textContent = String(state.connectedClients.size);
    if (!listEl) return;

    if (state.connectedClients.size === 0) {
      listEl.innerHTML =
        '<div class="text-xs text-slate-400 py-3 text-center border border-dashed border-slate-800 rounded-xl">Пока нет подключенных телефонов. Отсканируйте QR-код или введите код комнаты на телефоне.</div>';
      return;
    }

    listEl.innerHTML = '';
    state.connectedClients.forEach(function (info, peerId) {
      const row = document.createElement('div');
      row.className =
        'flex items-center justify-between px-3.5 py-2.5 rounded-xl bg-slate-900/90 border border-slate-800';
      row.innerHTML =
        '<div class="flex items-center gap-2.5">' +
        '<span class="w-2.5 h-2.5 rounded-full bg-emerald-400"></span>' +
        '<div>' +
        '<div class="text-xs font-semibold text-slate-100">' +
        escapeHtml(info.label) +
        '</div>' +
        '<div class="text-[11px] text-slate-400">Подключен в ' +
        escapeHtml(info.connectedAt) +
        ' • Opus Стерео</div>' +
        '</div>' +
        '</div>';

      const kickBtn = document.createElement('button');
      kickBtn.type = 'button';
      kickBtn.className =
        'px-2.5 py-1 rounded-lg text-xs font-medium bg-rose-500/15 text-rose-300 hover:bg-rose-500/25 border border-rose-500/30 transition';
      kickBtn.textContent = 'Отключить';
      kickBtn.addEventListener('click', function () {
        removeClient(peerId);
        showToast('Клиент отключен', 'info');
      });

      row.appendChild(kickBtn);
      listEl.appendChild(row);
    });
  }

  // --- Client (Phone): Connect to Host ---
  function connectToHostRoom() {
    const inputEl = document.getElementById('client-room-input');
    const rawCode = (inputEl ? inputEl.value : '').trim().toUpperCase().replace(/[^A-Z0-9]/g, '');
    if (!rawCode || rawCode.length < 4) {
      showToast('Введите 6-значный код комнаты с экрана ПК', 'warning');
      return;
    }

    ensureAudioContext();

    if (typeof window.Peer !== 'function') {
      showToast('PeerJS недоступен — используйте вкладку Ручной SDP или проверьте интернет', 'error');
      return;
    }

    disconnectFromHost();
    updateClientStatus('Подключение к ПК (' + rawCode + ')...', 'connecting');

    const clientPeer = new window.Peer(undefined, getPeerConfig());
    state.clientPeer = clientPeer;
    const targetPeerId = 'soundbridge-host-' + rawCode;

    clientPeer.on('open', function () {
      const conn = clientPeer.connect(targetPeerId, { reliable: true });
      state.clientConn = conn;

      conn.on('open', function () {
        updateClientStatus('Канал установлен, ожидание аудиопотока...', 'connecting');
        conn.send({
          type: 'request-stream',
          deviceLabel: getMobileDeviceName()
        });

        // Start ping interval
        if (state.statsIntervalId) clearInterval(state.statsIntervalId);
        state.statsIntervalId = setInterval(function () {
          if (state.clientConn && state.clientConn.open) {
            state.clientConn.send({ type: 'ping', ts: Date.now() });
          }
        }, 2000);
      });

      conn.on('data', function (data) {
        if (data && data.type === 'host-meta') {
          const codecBadge = document.getElementById('client-codec-info');
          if (codecBadge) {
            codecBadge.textContent =
              'Opus ' + (data.bitrate || 256) + ' kbps • ' + (data.stereo ? 'Стерео 48kHz' : 'Моно');
          }
        } else if (data && data.type === 'pong' && data.ts) {
          const rtt = Date.now() - data.ts;
          const pingEl = document.getElementById('client-ping-info');
          if (pingEl) pingEl.textContent = rtt + ' мс';
        }
      });

      conn.on('close', function () {
        showToast('Хост закрыл соединение', 'warning');
        disconnectFromHost();
      });
    });

    clientPeer.on('call', function (call) {
      state.clientCall = call;
      call.answer();
      call.on('stream', function (remoteStream) {
        handleIncomingRemoteStream(remoteStream);
      });
      call.on('close', function () {
        disconnectFromHost();
      });
    });

    clientPeer.on('error', function (err) {
      updateClientStatus('Ошибка подключения: проверьте код комнаты и что Хост запущен', 'idle');
      showToast('Не удалось найти Хост с кодом ' + rawCode + ' (' + (err.type || 'ошибка') + ')', 'error');
    });
  }

  function handleIncomingRemoteStream(remoteStream) {
    state.remoteStream = remoteStream;
    state.clientConnected = true;

    const audioEl = document.getElementById('remote-audio-player');
    if (audioEl) {
      audioEl.srcObject = remoteStream;
      audioEl.play().then(function () {
        state.clientPlaying = true;
        updatePlayButtonUi();
      }).catch(function () {
        // Mobile browser requires explicit tap on Play button
        state.clientPlaying = false;
        updatePlayButtonUi();
        showToast('Нажмите большую кнопку «Включить звук» для запуска воспроизведения на телефоне', 'info');
      });
    }

    buildAudioPipeline(remoteStream, true);
    setupMediaSession();
    updateClientStatus('Подключено к ПК — звук поступает в реальном времени', 'connected');
  }

  function disconnectFromHost() {
    if (state.statsIntervalId) {
      clearInterval(state.statsIntervalId);
      state.statsIntervalId = null;
    }
    if (state.clientCall) {
      try { state.clientCall.close(); } catch (e) {}
      state.clientCall = null;
    }
    if (state.clientConn) {
      try { state.clientConn.close(); } catch (e) {}
      state.clientConn = null;
    }
    if (state.clientPeer) {
      try { state.clientPeer.destroy(); } catch (e) {}
      state.clientPeer = null;
    }
    const audioEl = document.getElementById('remote-audio-player');
    if (audioEl) {
      audioEl.pause();
      audioEl.srcObject = null;
    }
    state.clientConnected = false;
    state.clientPlaying = false;
    updatePlayButtonUi();
    updateClientStatus('Отключено', 'idle');
  }

  function updateClientStatus(text, mode) {
    const statusEl = document.getElementById('client-status-banner');
    const connectBtn = document.getElementById('btn-client-connect');
    const disconnectBtn = document.getElementById('btn-client-disconnect');
    if (statusEl) {
      statusEl.textContent = text;
      statusEl.className =
        mode === 'connected'
          ? 'text-xs font-medium px-3.5 py-2.5 rounded-xl bg-emerald-500/15 text-emerald-300 border border-emerald-500/30'
          : mode === 'connecting'
          ? 'text-xs font-medium px-3.5 py-2.5 rounded-xl bg-sky-500/15 text-sky-300 border border-sky-500/30'
          : 'text-xs font-medium px-3.5 py-2.5 rounded-xl bg-slate-800/80 text-slate-400 border border-slate-700/70';
    }
    if (connectBtn) connectBtn.classList.toggle('hidden', mode === 'connected');
    if (disconnectBtn) disconnectBtn.classList.toggle('hidden', mode !== 'connected');
  }

  function updatePlayButtonUi() {
    const btn = document.getElementById('btn-client-play-toggle');
    if (!btn) return;
    if (state.clientPlaying) {
      btn.innerHTML =
        '<svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 9v6m4-6v6m7-3a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>' +
        '<span>Поставить звук на паузу</span>';
      btn.className =
        'w-full py-3.5 px-5 rounded-xl font-semibold text-sm flex items-center justify-center gap-2.5 bg-amber-500 hover:bg-amber-400 text-slate-950 transition shadow-lg shadow-amber-500/20';
    } else {
      btn.innerHTML =
        '<svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14.752 11.168l-3.197-2.132A1 1 0 0010 9.87v4.263a1 1 0 001.555.832l3.197-2.132a1 1 0 000-1.664z"/><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>' +
        '<span>Включить воспроизведение звука</span>';
      btn.className =
        'w-full py-3.5 px-5 rounded-xl font-semibold text-sm flex items-center justify-center gap-2.5 bg-sky-500 hover:bg-sky-400 text-slate-950 transition shadow-lg shadow-sky-500/25';
    }
  }

  function getMobileDeviceName() {
    const ua = navigator.userAgent || '';
    if (/iPhone/i.test(ua)) return 'iPhone (iOS)';
    if (/iPad/i.test(ua)) return 'iPad (iPadOS)';
    if (/Android/i.test(ua)) return 'Android Смартфон';
    return 'Клиент (' + (navigator.platform || 'Браузер') + ')';
  }

  // --- WakeLock & MediaSession for Background Audio on Phone ---
  async function toggleWakeLock(enable) {
    const statusText = document.getElementById('wakelock-status');
    if (!('wakeLock' in navigator)) {
      if (statusText) statusText.textContent = 'Не поддерживается браузером';
      showToast('WakeLock API не поддерживается в этом браузере', 'warning');
      return;
    }
    try {
      if (enable) {
        state.wakeLock = await navigator.wakeLock.request('screen');
        if (statusText) statusText.textContent = 'Экран активен (не погаснет)';
        showToast('Удержание экрана включено — звук не прервется', 'info');
      } else {
        if (state.wakeLock) {
          await state.wakeLock.release();
          state.wakeLock = null;
        }
        if (statusText) statusText.textContent = 'Выключено';
      }
    } catch (e) {
      if (statusText) statusText.textContent = 'Недоступно во фрейме';
    }
  }

  function setupMediaSession() {
    if ('mediaSession' in navigator) {
      try {
        navigator.mediaSession.metadata = new MediaMetadata({
          title: 'Звук с ПК (Комната ' + (state.roomCode || 'Live') + ')',
          artist: 'SoundBridge P2P Audio',
          album: 'Прямая WebRTC трансляция'
        });
        navigator.mediaSession.setActionHandler('play', function () {
          toggleClientPlay(true);
        });
        navigator.mediaSession.setActionHandler('pause', function () {
          toggleClientPlay(false);
        });
      } catch (e) {}
    }
  }

  function toggleClientPlay(forceState) {
    ensureAudioContext();
    const audioEl = document.getElementById('remote-audio-player');
    if (!state.remoteStream) {
      // Allow testing local synth on phone if not yet connected to a host
      const demoStream = createDemoSynthStream();
      handleIncomingRemoteStream(demoStream);
      showToast('Запущен тестовый аудиопоток для проверки эквалайзера и громкости на телефоне!', 'info');
      return;
    }
    const nextState = typeof forceState === 'boolean' ? forceState : !state.clientPlaying;
    if (nextState) {
      if (audioEl) audioEl.play().catch(function () {});
      if (state.audioCtx && state.audioCtx.state === 'suspended') state.audioCtx.resume();
      state.clientPlaying = true;
    } else {
      if (audioEl) audioEl.pause();
      if (state.audioCtx && state.audioCtx.state === 'running') state.audioCtx.suspend();
      state.clientPlaying = false;
    }
    updatePlayButtonUi();
  }

  // --- Manual Serverless WebRTC SDP Fallback (100% Zero Third-Party Server) ---
  async function createManualHostOffer() {
    if (!state.processedStream) {
      await startHostBroadcast();
      if (!state.processedStream) return;
    }
    if (state.manualPeerConn) {
      state.manualPeerConn.close();
    }
    const pc = new RTCPeerConnection({
      iceServers: [{ urls: 'stun:stun.l.google.com:19302' }]
    });
    state.manualPeerConn = pc;
    state.processedStream.getTracks().forEach(function (track) {
      pc.addTrack(track, state.processedStream);
    });

    pc.onicecandidate = function (ev) {
      if (!ev.candidate && pc.localDescription) {
        const sdpStr = btoa(JSON.stringify(pc.localDescription));
        const out = document.getElementById('manual-sdp-offer');
        if (out) out.value = sdpStr;
        showToast('SDP-код Хоста готов! Скопируйте и вставьте его на телефоне', 'info');
      }
    };

    const offer = await pc.createOffer();
    offer.sdp = enhanceOpusSdp(offer.sdp, state.bitrate, state.stereo);
    await pc.setLocalDescription(offer);
  }

  async function applyManualClientAnswerOnHost() {
    const ansInput = document.getElementById('manual-sdp-host-answer-in');
    if (!ansInput || !ansInput.value.trim() || !state.manualPeerConn) {
      showToast('Сначала создайте SDP-код Хоста и вставьте ответный код с телефона', 'warning');
      return;
    }
    try {
      const desc = JSON.parse(atob(ansInput.value.trim()));
      await state.manualPeerConn.setRemoteDescription(new RTCSessionDescription(desc));
      registerClient('manual-p2p', null, null, 'Смартфон (Прямой P2P SDP)');
      showToast('Прямое P2P соединение с телефоном установлено!', 'info');
    } catch (e) {
      showToast('Неверный формат ответного SDP-кода', 'error');
    }
  }

  async function acceptManualOfferOnClient() {
    const offerIn = document.getElementById('manual-client-offer-in');
    if (!offerIn || !offerIn.value.trim()) {
      showToast('Вставьте SDP-код с ПК', 'warning');
      return;
    }
    try {
      const desc = JSON.parse(atob(offerIn.value.trim()));
      const pc = new RTCPeerConnection({
        iceServers: [{ urls: 'stun:stun.l.google.com:19302' }]
      });
      state.manualPeerConn = pc;
      pc.ontrack = function (ev) {
        if (ev.streams && ev.streams[0]) {
          handleIncomingRemoteStream(ev.streams[0]);
        }
      };
      pc.onicecandidate = function (ev) {
        if (!ev.candidate && pc.localDescription) {
          const ansOut = document.getElementById('manual-client-answer-out');
          if (ansOut) ansOut.value = btoa(JSON.stringify(pc.localDescription));
          showToast('Ответный код создан! Скопируйте и отправьте его на ПК', 'info');
        }
      };
      await pc.setRemoteDescription(new RTCSessionDescription(desc));
      const answer = await pc.createAnswer();
      await pc.setLocalDescription(answer);
    } catch (e) {
      showToast('Не удалось обработать SDP-код Хоста', 'error');
    }
  }

  // --- Role Switching & UI Event Wiring ---
  function switchRole(role) {
    state.role = role;
    const hostPanel = document.getElementById('panel-host');
    const clientPanel = document.getElementById('panel-client');
    const guidePanel = document.getElementById('panel-guide');

    const tabHost = document.getElementById('tab-role-host');
    const tabClient = document.getElementById('tab-role-client');
    const tabGuide = document.getElementById('tab-role-guide');

    if (hostPanel) hostPanel.classList.toggle('hidden', role !== 'host');
    if (clientPanel) clientPanel.classList.toggle('hidden', role !== 'client');
    if (guidePanel) guidePanel.classList.toggle('hidden', role !== 'guide');

    const activeCls =
      'px-4 py-2.5 rounded-xl text-xs sm:text-sm font-semibold bg-sky-500 text-slate-950 shadow-md shadow-sky-500/20 transition flex items-center gap-2';
    const inactiveCls =
      'px-4 py-2.5 rounded-xl text-xs sm:text-sm font-medium text-slate-300 hover:text-white hover:bg-slate-800/70 transition flex items-center gap-2';

    if (tabHost) tabHost.className = role === 'host' ? activeCls : inactiveCls;
    if (tabClient) tabClient.className = role === 'client' ? activeCls : inactiveCls;
    if (tabGuide) tabGuide.className = role === 'guide' ? activeCls : inactiveCls;
  }

  function applyEqPreset(prefix, bassVal, midVal, trebleVal) {
    const bEl = document.getElementById(prefix + '-eq-bass');
    const mEl = document.getElementById(prefix + '-eq-mid');
    const tEl = document.getElementById(prefix + '-eq-treble');
    if (bEl) bEl.value = String(bassVal);
    if (mEl) mEl.value = String(midVal);
    if (tEl) tEl.value = String(trebleVal);

    if (state.eqNodes.bass) state.eqNodes.bass.gain.value = bassVal;
    if (state.eqNodes.mid) state.eqNodes.mid.gain.value = midVal;
    if (state.eqNodes.treble) state.eqNodes.treble.gain.value = trebleVal;

    const bLabel = document.getElementById(prefix + '-eq-bass-val');
    const mLabel = document.getElementById(prefix + '-eq-mid-val');
    const tLabel = document.getElementById(prefix + '-eq-treble-val');
    if (bLabel) bLabel.textContent = (bassVal >= 0 ? '+' : '') + bassVal + ' dB';
    if (mLabel) mLabel.textContent = (midVal >= 0 ? '+' : '') + midVal + ' dB';
    if (tLabel) tLabel.textContent = (trebleVal >= 0 ? '+' : '') + trebleVal + ' dB';
  }

  function initApp() {
    state.roomCode = generateRoomCode();
    updateRoomDisplay();
    refreshAudioDevices();
    renderConnectedClients();
    startVisualizer();

    // Check URL params for auto-client mode (?role=client&room=XXXXXX)
    const params = new URLSearchParams(window.location.search);
    const urlRoom = params.get('room');
    const urlRole = params.get('role');
    if (urlRoom) {
      const clientInput = document.getElementById('client-room-input');
      if (clientInput) clientInput.value = urlRoom.toUpperCase();
      switchRole('client');
    } else if (urlRole === 'client') {
      switchRole('client');
    } else {
      switchRole('host');
    }

    // Role Tabs
    document.getElementById('tab-role-host')?.addEventListener('click', function () {
      switchRole('host');
    });
    document.getElementById('tab-role-client')?.addEventListener('click', function () {
      switchRole('client');
    });
    document.getElementById('tab-role-guide')?.addEventListener('click', function () {
      switchRole('guide');
    });

    // Source Type Radio Buttons
    document.querySelectorAll('[data-source-type]').forEach(function (btn) {
      btn.addEventListener('click', function () {
        const type = btn.getAttribute('data-source-type');
        state.sourceType = type;
        document.querySelectorAll('[data-source-type]').forEach(function (b) {
          const isSelected = b.getAttribute('data-source-type') === type;
          b.className = isSelected
            ? 'p-3 rounded-xl border border-sky-500 bg-sky-500/15 text-left transition'
            : 'p-3 rounded-xl border border-slate-800 bg-slate-900/60 hover:border-slate-700 text-left transition';
        });
        document.getElementById('device-picker-box')?.classList.toggle('hidden', type !== 'device');
        document.getElementById('file-picker-box')?.classList.toggle('hidden', type !== 'file');
      });
    });

    document.getElementById('btn-refresh-devices')?.addEventListener('click', function () {
      refreshAudioDevices();
      showToast('Список аудиоустройств обновлен', 'info');
    });

    // Bitrate & Stereo Controls
    document.getElementById('host-bitrate-select')?.addEventListener('change', function (e) {
      state.bitrate = parseInt(e.target.value, 10) || 256;
      if (state.isStreaming) updateHostUiStatus(true);
    });

    document.getElementById('host-stereo-toggle')?.addEventListener('change', function (e) {
      state.stereo = e.target.checked;
    });

    document.getElementById('host-monitor-toggle')?.addEventListener('change', function (e) {
      state.localMonitor = e.target.checked;
      if (state.gainNode && state.audioCtx) {
        try {
          if (state.localMonitor) {
            state.gainNode.connect(state.audioCtx.destination);
          } else {
            state.gainNode.disconnect(state.audioCtx.destination);
          }
        } catch (err) {}
      }
    });

    document.getElementById('host-gain')?.addEventListener('input', function (e) {
      const val = parseInt(e.target.value, 10);
      const label = document.getElementById('host-gain-val');
      if (label) label.textContent = val + '%';
      if (state.gainNode && state.role === 'host') {
        state.gainNode.gain.value = val / 100;
      }
    });

    // Host Start / Stop / Room Code Actions
    document.getElementById('btn-host-start')?.addEventListener('click', startHostBroadcast);
    document.getElementById('btn-host-stop')?.addEventListener('click', stopHostBroadcast);

    document.getElementById('btn-regenerate-code')?.addEventListener('click', function () {
      state.roomCode = generateRoomCode();
      updateRoomDisplay();
      if (state.isStreaming) initHostPeer();
      showToast('Сгенерирован новый код комнаты: ' + state.roomCode, 'info');
    });

    document.getElementById('btn-copy-code')?.addEventListener('click', function () {
      copyText(state.roomCode, 'Код комнаты ' + state.roomCode + ' скопирован!');
    });

    document.getElementById('btn-copy-url')?.addEventListener('click', function () {
      copyText(getShareUrl(), 'Прямая ссылка для телефона скопирована!');
    });

    // Signaling Mode Selector
    document.getElementById('signaling-mode-select')?.addEventListener('change', function (e) {
      state.signalingMode = e.target.value;
      document.getElementById('custom-server-config')?.classList.toggle('hidden', state.signalingMode !== 'custom');
      document.getElementById('manual-sdp-host-box')?.classList.toggle('hidden', state.signalingMode !== 'manual');
      document.getElementById('manual-sdp-client-box')?.classList.toggle('hidden', state.signalingMode !== 'manual');
    });

    // Manual SDP Buttons
    document.getElementById('btn-manual-create-offer')?.addEventListener('click', createManualHostOffer);
    document.getElementById('btn-manual-copy-offer')?.addEventListener('click', function () {
      const val = document.getElementById('manual-sdp-offer')?.value || '';
      if (val) copyText(val, 'SDP-код Хоста скопирован!');
    });
    document.getElementById('btn-manual-apply-answer')?.addEventListener('click', applyManualClientAnswerOnHost);
    document.getElementById('btn-manual-client-accept')?.addEventListener('click', acceptManualOfferOnClient);
    document.getElementById('btn-manual-copy-answer')?.addEventListener('click', function () {
      const val = document.getElementById('manual-client-answer-out')?.value || '';
      if (val) copyText(val, 'Ответный SDP-код скопирован!');
    });

    // Client Controls
    document.getElementById('btn-client-connect')?.addEventListener('click', connectToHostRoom);
    document.getElementById('btn-client-disconnect')?.addEventListener('click', disconnectFromHost);
    document.getElementById('btn-client-play-toggle')?.addEventListener('click', function () {
      toggleClientPlay();
    });

    document.getElementById('client-volume')?.addEventListener('input', function (e) {
      const val = parseInt(e.target.value, 10);
      const label = document.getElementById('client-volume-val');
      if (label) label.textContent = val + '%';
      if (state.gainNode) {
        state.gainNode.gain.value = val / 100;
      }
    });

    // Client Equalizer Sliders & Presets
    ['bass', 'mid', 'treble'].forEach(function (band) {
      const slider = document.getElementById('client-eq-' + band);
      slider?.addEventListener('input', function (e) {
        const val = parseFloat(e.target.value);
        const label = document.getElementById('client-eq-' + band + '-val');
        if (label) label.textContent = (val >= 0 ? '+' : '') + val + ' dB';
        if (state.eqNodes[band]) {
          state.eqNodes[band].gain.value = val;
        }
      });
    });

    document.querySelectorAll('[data-eq-preset]').forEach(function (btn) {
      btn.addEventListener('click', function () {
        const parts = (btn.getAttribute('data-eq-preset') || '0,0,0').split(',').map(Number);
        applyEqPreset('client', parts[0], parts[1], parts[2]);
        showToast('Применен пресет эквалайзера: ' + btn.textContent.trim(), 'info');
      });
    });

    document.getElementById('client-wakelock-toggle')?.addEventListener('change', function (e) {
      toggleWakeLock(e.target.checked);
    });

    // Visualizer Mode Toggle
    document.getElementById('btn-viz-bars')?.addEventListener('click', function () {
      state.vizMode = 'bars';
    });
    document.getElementById('btn-viz-wave')?.addEventListener('click', function () {
      state.vizMode = 'wave';
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initApp);
  } else {
    initApp();
  }
})();
