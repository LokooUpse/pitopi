// Optional Node.js + Express + PeerServer backend
// Note: The front-end works 100% WITHOUT this server on any free static host
// (GitHub Pages, Netlify, Vercel, Cloudflare Pages) using PeerJS Cloud + Google STUN.
// Use this server only if you deploy on Render.com / Glitch / Railway or want a local LAN signaling server.

const path = require('path');
const express = require('express');
const { ExpressPeerServer } = require('peer');

const app = express();
const PORT = process.env.PORT || 9000;

app.use(express.static(path.join(__dirname, '..')));

const server = app.listen(PORT, () => {
  console.log(`SoundBridge server running on http://localhost:${PORT}`);
});

const peerServer = ExpressPeerServer(server, {
  debug: true,
  path: '/myapp',
  allow_discovery: false
});

app.use('/peerjs', peerServer);
